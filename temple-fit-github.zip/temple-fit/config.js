// Optional. Paste the address of your AI helper here to turn on meal photo scans and AI food estimates.
// Leave it empty to use the app without them (you can still take photos and type the numbers yourself).
window.TF_AI_URL = "";
