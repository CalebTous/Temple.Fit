# Temple Fit on GitHub Pages

Files in this folder: `index.html` (the app), `shim.js`, `config.js`, `worker.js` (optional), this README.

## 1. Put the app on GitHub (about 5 minutes)

1. Make a free account at github.com.
2. Click **+ > New repository**. Name it `temple-fit`, choose **Public**, click **Create repository**.
3. Click **uploading an existing file**. Drag in `index.html`, `shim.js` and `config.js`. Click **Commit changes**.
4. Go to **Settings > Pages**. Under Branch, pick `main` and `/ (root)`, then **Save**.
5. Wait 1 to 2 minutes. Your app is at `https://YOUR-USERNAME.github.io/temple-fit/`.
6. On a phone, open that link, then use **Share > Add to Home Screen**.

What works right away: workouts, food, water, quests, PR Days, schedule, reminders while the app is open, progress photos (stored on that device), and meal photos where you type the numbers yourself.

Your data is saved in each person's own browser. It does not move between devices.

## 2. Turn on photo scans and AI food estimates (optional)

This needs a small helper that holds your Anthropic API key. Never put the key in the web page.

1. Make a free account at cloudflare.com. Go to **Workers & Pages > Create > Create Worker**. Name it `temple-fit-ai` and click **Deploy**.
2. Click **Edit code**. Replace everything with the contents of `worker.js`. Click **Deploy**.
3. Open the Worker's **Settings > Variables and Secrets** and add:
   - `ANTHROPIC_API_KEY` as a **Secret**: your key from console.anthropic.com
   - `ALLOWED_ORIGIN` as **Text**: `https://YOUR-USERNAME.github.io` (no slash at the end, no path)
4. Copy the Worker's address (it looks like `https://temple-fit-ai.YOURNAME.workers.dev`).
5. On GitHub, open `config.js`, click the pencil, set `window.TF_AI_URL = "THAT ADDRESS";` and commit.
6. Reload the app. Photo scans and AI estimates are now on.

Protect your wallet: in the Anthropic console, set a monthly spend limit. Anyone who finds your Worker address from the allowed site can use it, and you pay for what they use. Share the app only with people you trust.

## Not included here

Accounts that sync across devices, and push notifications while the app is closed. These need a server and can be added later.
