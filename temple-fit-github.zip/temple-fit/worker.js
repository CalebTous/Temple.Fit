// Cloudflare Worker: the AI helper for Temple Fit's photo scans and food estimates.
// Your Anthropic API key stays here, never in the web page.
// Settings > Variables and Secrets:
//   ANTHROPIC_API_KEY  (secret)  your key
//   ALLOWED_ORIGIN     (text)    e.g. https://YOUR-USERNAME.github.io
export default {
  async fetch(req, env) {
    const origin = req.headers.get("Origin") || "";
    const cors = {
      "Access-Control-Allow-Origin": env.ALLOWED_ORIGIN || "",
      "Access-Control-Allow-Methods": "POST, OPTIONS",
      "Access-Control-Allow-Headers": "Content-Type",
      "Vary": "Origin"
    };
    if (req.method === "OPTIONS") return new Response(null, { status: 204, headers: cors });
    if (req.method !== "POST" || !env.ALLOWED_ORIGIN || origin !== env.ALLOWED_ORIGIN)
      return new Response(JSON.stringify({ error: "not allowed" }), { status: 403, headers: cors });
    let body;
    try { body = await req.json(); } catch { return new Response(JSON.stringify({ error: "bad request" }), { status: 400, headers: cors }); }
    const prompt = String(body.prompt || "").slice(0, 6000);
    const images = (Array.isArray(body.images) ? body.images : []).slice(0, 2).filter(s => typeof s === "string" && s.length < 3_000_000);
    if (!prompt) return new Response(JSON.stringify({ error: "empty" }), { status: 400, headers: cors });
    const content = images.map(data => ({ type: "image", source: { type: "base64", media_type: "image/jpeg", data } }));
    content.push({ type: "text", text: prompt });
    const r = await fetch("https://api.anthropic.com/v1/messages", {
      method: "POST",
      headers: { "content-type": "application/json", "x-api-key": env.ANTHROPIC_API_KEY, "anthropic-version": "2023-06-01" },
      body: JSON.stringify({
        model: "claude-haiku-5-5",
        max_tokens: 1500,
        system: "Reply with only one JSON object. No markdown and no text outside the JSON.",
        messages: [{ role: "user", content }]
      })
    });
    if (r.status === 429) return new Response(JSON.stringify({ error: "rate" }), { status: 429, headers: cors });
    if (!r.ok) return new Response(JSON.stringify({ error: "upstream " + r.status }), { status: 502, headers: cors });
    const data = await r.json();
    const text = ((data.content || []).find(c => c.type === "text") || {}).text || "";
    const a = text.indexOf("{"), b = text.lastIndexOf("}");
    try {
      const obj = JSON.parse(text.slice(a, b + 1));
      return new Response(JSON.stringify(obj), { headers: { ...cors, "content-type": "application/json" } });
    } catch {
      return new Response(JSON.stringify({ error: "invalid json" }), { status: 502, headers: cors });
    }
  }
};
