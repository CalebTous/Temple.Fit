/* Temple Fit for GitHub Pages: replaces the parts that only exist inside Claude.
   - Saved data stays in this browser (localStorage / IndexedDB).
   - Downloads use a normal browser download.
   - Photo and AI food estimates turn on only when config.js has an AI helper address. */
(function(){
  var URL_AI=(window.TF_AI_URL||'').trim();
  function toB64(file,max){return new Promise(function(res,rej){
    var u=URL.createObjectURL(file),im=new Image();
    im.onload=function(){var s=Math.min(1,max/Math.max(im.width,im.height)),c=document.createElement('canvas');
      c.width=Math.round(im.width*s);c.height=Math.round(im.height*s);c.getContext('2d').drawImage(im,0,0,c.width,c.height);
      URL.revokeObjectURL(u);res(c.toDataURL('image/jpeg',0.8).split(',')[1])};
    im.onerror=function(){URL.revokeObjectURL(u);var e=new Error('image');e.code='image_rejected';rej(e)};
    im.src=u})}
  var dl={save:function(o){return new Promise(function(res){
    var b=o.data instanceof Blob?o.data:new Blob([o.data],{type:'text/plain'}),a=document.createElement('a');
    a.href=URL.createObjectURL(b);a.download=o.filename||'download';document.body.appendChild(a);a.click();
    setTimeout(function(){URL.revokeObjectURL(a.href);a.remove();res()},800)})}};
  var sample={
    limits:function(){return Promise.resolve({images:true})},
    json:async function(prompt,opts){
      opts=opts||{};var body={prompt:String(prompt)};
      if(opts.images){var list=Array.isArray(opts.images)?opts.images:[opts.images];body.images=[];
        for(var i=0;i<list.length;i++)body.images.push(await toB64(list[i],1024))}
      var r;try{r=await fetch(URL_AI,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(body),signal:opts.signal})}
      catch(e){if(e&&e.name==='AbortError'){var c=new Error('cancelled');c.code='cancelled';throw c}var n=new Error('network');n.code='network';throw n}
      if(r.status===429){var t=new Error('rate');t.code='rate_limited';throw t}
      if(!r.ok){var f=new Error('failed');f.code='failed';throw f}
      var j=await r.json();if(j&&j.error){var x=new Error(j.error);x.code='invalid_json';throw x}return j}};
  window.claude={use:function(name){
    if(name==='downloads')return Promise.resolve(dl);
    if(name==='sample')return Promise.resolve(URL_AI?sample:null);
    return Promise.resolve(null)}};
})();
